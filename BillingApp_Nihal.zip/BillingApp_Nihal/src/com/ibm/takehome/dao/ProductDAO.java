package com.ibm.takehome.dao;

public class ProductDAO implements IProductDAO{

}
