package com.ibm.takehome.service;


import com.ibm.takehome.bean.Product;

public interface IProductService {
	
	void generateBill();
	Product getProductDetails (int productCode); 
	void showProductDetails(Product product, int qty);
	
	//String userNamePattern="[A-Z][a-z]{9}";
	//boolean validateUserName(String userName);
    //void storeIntoMap(Product product);
	
	//Map<Integer,Product> displayPersons();

}
